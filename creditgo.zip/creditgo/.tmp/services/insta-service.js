import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { InstaRequest } from '../models/insta-request';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/timeout';
export var InstaService = (function () {
    function InstaService(http) {
        this.http = http;
        // get base url
        /*
        http.get(InstaService.APP_CONFIG)
          .map(res => res.json())
          .subscribe(
            data => {
                console.log("Done getting appconfig...");
                this._url = data.serviceBaseUrl;
                console.log("baseUrl: " + this._url);
            },
            error=>{
                console.log("Can't load '" + InstaService.APP_CONFIG + JSON.stringify(error));
            });
            */
    }
    InstaService.prototype.getAppConfig = function () {
        return this.http.get(InstaService.APP_CONFIG)
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    InstaService.prototype.getRankedCounterpartiesByNameQuery = function (nameQuery) {
        var jsonReq = '{ "nameQuery":"' + nameQuery + '"}';
        console.log("Getting a ranked cp - userid:json " + this.userid + ":" + jsonReq);
        var req = new InstaRequest('get/rankedcounterparty/query', this.userid, jsonReq);
        return this.getData(req);
    };
    InstaService.prototype.getRankedCounterparties = function () {
        console.log("Getting ranked cp - userid: " + this.userid);
        var req = new InstaRequest('get/rankedcounterparty', this.userid, "{}");
        return this.getData(req);
    };
    InstaService.prototype.getCounterpartyDetail = function (id) {
        var jsonReq = '{ "id":' + id + '}';
        console.log("Getting cp - id:userid:json " + id + ":" + this.userid + ":" + jsonReq);
        var req = new InstaRequest('get/counterparty', this.userid, jsonReq);
        return this.getData(req);
    };
    //mock
    InstaService.prototype.MOCK_getCounterpartyCurrentLimitsAndExposures = function (counterpartyName) {
        return this.http.get('mock/exposure.json')
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    InstaService.prototype.getCounterpartyCurrentLimitsAndExposures = function (counterpartyName) {
        var jsonReq = '{ "counterpartyName": "' + counterpartyName + '" }';
        console.log("Getting cp/currentexposure - name:userid:json " + counterpartyName + ":" + this.userid + ":" + jsonReq);
        var req = new InstaRequest('get/counterparty/currentexposure', this.userid, jsonReq);
        return this.getData(req);
    };
    // mock
    InstaService.prototype.MOCK_getCounterpartyCaFiles = function (id) {
        return this.http.get('mock/cafiles.json')
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    InstaService.prototype.getCounterpartyCaFiles = function (id) {
        var jsonReq = '{ "id":' + id + '}';
        console.log("Getting cp ca folder - id:userid:json " + id + ":" + this.userid + ":" + jsonReq);
        var req = new InstaRequest('get/counterparty/spfiles', this.userid, jsonReq);
        return this.getData(req);
    };
    //mock method
    InstaService.prototype.MOCK_getCounterpartyCaFileBase64 = function (url) {
        return this.http.get('mock/file64.json')
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    InstaService.prototype.getCounterpartyCaFileBase64 = function (url) {
        var jsonReq = '{ "fileUrl":"' + url + '"}';
        console.log("Getting a cafile - userid:json " + this.userid + ":" + jsonReq);
        var req = new InstaRequest('get/fileasbase64', this.userid, jsonReq);
        return this.getData(req);
    };
    //mock method
    InstaService.prototype.MOCK_getExposuresAndLimitsGroupByRatingBand = function () {
        return this.http.get('mock/exp_and_el_by_ratingband.json')
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    InstaService.prototype.getExposuresAndLimitsGroupByRatingBand = function () {
        console.log("Getting rating band exposures: " + this.userid);
        var req = new InstaRequest('get/currentRatingBandExposureAndExpectedLoss', this.userid, "{}");
        return this.getData(req);
    };
    //mock method
    InstaService.prototype.MOCK_getExposuresAndLimitsGroupByTeam = function () {
        return this.http.get('mock/exp_and_el_by_team.json')
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    InstaService.prototype.getExposuresAndLimitsGroupByTeam = function () {
        console.log("Getting team exposures - userid: " + this.userid);
        var req = new InstaRequest('get/currentTeamExposureAndExpectedLoss', this.userid, "{}");
        return this.getData(req);
    };
    InstaService.prototype.getHistoricalExposuresAndExpectedLosses = function () {
        console.log("Getting team exposures - userid: " + this.userid);
        var req = new InstaRequest('get/historicExposureGroupByDate', this.userid, "{}");
        return this.getData(req);
    };
    InstaService.prototype.getTopCounterpartyExposures = function () {
        console.log("Getting team exposures - userid: " + this.userid);
        var req = new InstaRequest('get/topCounterpartyExposureAndExpectedLoss', this.userid, "{}");
        return this.getData(req);
    };
    // set user credential for url
    InstaService.prototype.setServiceCredential = function (url, userid, password) {
        this._url = url;
        this.userid = userid;
        this.password = password;
        console.log("Credential: " + this._url + ":" + this.userid);
    };
    // authenticate a user.  This has been call from 
    InstaService.prototype.authenticate = function () {
        var jsonReq = '{}';
        var req = new InstaRequest('get/logon', this.userid, jsonReq);
        return this.getData(req);
        /*

        console.log("authenticate()... user" + this.userid);
        let soapRequest = '';
        let headers = this.createHeaders();
      
        return this.http.post(this._url, soapRequest, {
            headers: headers
        }).map((resp)=> {
            // store for next time use
            console.log("Logging in succesfully...")
            return resp;
        })
        .catch(this.handleError);
        */
    };
    InstaService.encodeXml = function (value) {
        return value.replace(/([\&"'<>])/g, function (str, item) {
            return InstaService.XML_ESCAPE_MAP[item];
        });
    };
    ;
    InstaService.prototype.createSoapRequest = function (request) {
        return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:onec=\"http://onecreditportal.am.ist.bp.com\">\n                        <soapenv:Header/>\n                        <soapenv:Body>\n                            <onec:InstaCreditRequest>\n                                <onec:request>\n                                    <onec:Route>" + request.route + "</onec:Route>\n                                    <onec:UserId>" + request.userId + "</onec:UserId>\n                                    <onec:JsonRequest>" + InstaService.encodeXml(request.jsonRequest) + "</onec:JsonRequest>\n                                </onec:request>\n                            </onec:InstaCreditRequest>\n                        </soapenv:Body>\n                        </soapenv:Envelope>";
    };
    InstaService.prototype.createHeaders = function () {
        var headers = new Headers();
        // passing your password
        headers.append('Content-Type', 'application/soap+xml; charset=UTF-8');
        headers.append('Authorization', 'Basic ' + btoa(this.userid + ':' + this.password));
        return headers;
    };
    InstaService.prototype.getData = function (instaRequest) {
        console.log("getData()... user" + this.userid);
        var soapRequest = this.createSoapRequest(instaRequest);
        var headers = this.createHeaders();
        console.log("url: " + this._url);
        return this.http.post(this._url, soapRequest, {
            headers: headers
        })
            .map(function (resp) {
            console.log("getData(): map.....: " + instaRequest.route + "...");
            var parser = new DOMParser();
            var xmlDoc = parser.parseFromString(resp.text(), "text/xml");
            var jsonString = xmlDoc.getElementsByTagName("JsonResponse")[0].childNodes[0].nodeValue;
            return JSON.parse(jsonString);
        })
            .catch(this.handleError);
    };
    InstaService.prototype.handleError = function (error) {
        if (error instanceof Response) {
            console.log("Ws Error: " + JSON.stringify(error));
            return Observable.throw(error.json().error || 'Backend server error');
        }
        else {
            console.log("Ws Error: (non-respose)" + JSON.stringify(error));
            return Observable.throw("Ws Error: (non-respose)" + JSON.stringify(error) || 'Backend server error');
        }
    };
    InstaService.APP_CONFIG = 'appconfig/appconfig.json';
    InstaService.XML_ESCAPE_MAP = { '&': '&amp;',
        '"': '&quot;',
        "'": '&apos;',
        '<': '&lt;',
        '>': '&gt;'
    };
    InstaService.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    InstaService.ctorParameters = [
        { type: Http, },
    ];
    return InstaService;
}());
