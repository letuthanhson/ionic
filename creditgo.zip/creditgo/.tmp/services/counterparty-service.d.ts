import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
export declare class CounterpartyService {
    private http;
    private db;
    constructor(http: Http);
    getRankedCounterparties(http: Http): any;
    getCounterparty(counterpartyId: number): Observable<any>;
    handleError(error: any): any;
}
