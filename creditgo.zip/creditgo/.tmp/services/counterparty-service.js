import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { SQLite } from 'ionic-native';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
export var CounterpartyService = (function () {
    //private storage: Storage = new Storage(SqlStorage);
    //getRankedCounterparties1() {
    // return Promise.resolve(RANKED_COUNTERPARTIES);
    //}
    function CounterpartyService(http) {
        this.http = http;
        this.db = new SQLite();
    }
    CounterpartyService.prototype.getRankedCounterparties = function (http) {
        return Promise.resolve(http.get('mock/rankedcps.json')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            return data;
        }));
    };
    /*
    findCounterparty(counterparty: RankedCounterparty, counterparties: any[]) {
      for (let i=0; i < counterparties.length; i++) {
        if (counterparties[i].id === counterparty.id) {
          return counterparties[i];
        }
      }
    }
    */
    /*
    getCounterparty1(counterparty: RankedCounterparty):any
    {
        return Promise.resolve(
          this.db.openDatabase({
            name: 'data.db',
            location: 'default'
          }).then(() => {
            this.db.executeSql("select cou from Counterparty where id = ?", [counterparty.id])
            .then(o => {
              console.log(counterparty.id, o);
              return JSON.parse(o);
            },
            (e) => {
                console.log("Unable to get counterparty", e);
            })
        },
        (e) => {
            console.log("Unable to open database", e);
        }));
    }
    getCounterparty2(counterparty: RankedCounterparty):any
    {
        return Promise.resolve(this.db.openDatabase({
            name: 'data.db',
            location: 'default'
          }).then(() => {
            this.db.executeSql("select counterparty from Counterparty where id = ?", [counterparty.id])
            .then(result => {
              if (result.rows.length > 0) {
                console.log(JSON.parse(result.rows.item(0).counterparty));
                return JSON.parse(result.rows.item(0).counterparty);
              }
              else
                return undefined;
            },
            (e) => {
                console.log("Unable to get counterparty", JSON.stringify(e));
            })
        },
        (e) => {
            console.log("Unable to open database", JSON.stringify(e));
        }));
    }
    */
    CounterpartyService.prototype.getCounterparty = function (counterpartyId) {
        var _this = this;
        return Observable.create(function (observer) {
            _this.db.openDatabase({
                name: 'data.db',
                location: 'default'
            })
                .then(function () {
                return _this.db.executeSql("select counterparty from Counterparty where id = ?", [counterpartyId]);
            })
                .then(function (result) {
                if (result.rows.length > 0) {
                    console.log(JSON.parse(result.rows.item(0).counterparty));
                    observer.next(JSON.parse(result.rows.item(0).counterparty));
                }
                else
                    return observer.next(undefined);
            })
                .catch(function (e) {
                console.log("Error: ", JSON.stringify(e));
                observer.error(new Error("Error" + JSON.stringify(e)));
            });
        });
    };
    CounterpartyService.prototype.handleError = function (error) {
        if (error instanceof Response) {
            return Observable.throw(error.json().error || 'Backend server error');
        }
        else {
            return Observable.throw(error || "Bankend serve error");
        }
    };
    CounterpartyService.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    CounterpartyService.ctorParameters = [
        { type: Http, },
    ];
    return CounterpartyService;
}());
