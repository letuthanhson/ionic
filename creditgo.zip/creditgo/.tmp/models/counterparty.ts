export class Counterparty {
    id: number;
    name: string;
}