export var Counterparty = (function () {
    function Counterparty() {
    }
    return Counterparty;
}());
