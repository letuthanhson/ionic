export var LogonUser = (function () {
    function LogonUser() {
        this.rememberMe = false;
    }
    return LogonUser;
}());
