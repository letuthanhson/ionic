export interface Limit {
    start: Date;
    limit: number;
}
export interface Exposure {
    start: Date;
    exposure: number;
}
export interface CpLimitAndExposure {
    exposureDate: Date;
    limit: number;
    currentExposure: number;
}
