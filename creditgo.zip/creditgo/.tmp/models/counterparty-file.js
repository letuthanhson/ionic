export var CounterpartyFile = (function () {
    function CounterpartyFile() {
    }
    return CounterpartyFile;
}());
