export declare class InstaRequest {
    source: string;
    route: string;
    userId: string;
    jsonRequest: string;
    constructor(route: string, userId: string, jsonRequest: string);
}
