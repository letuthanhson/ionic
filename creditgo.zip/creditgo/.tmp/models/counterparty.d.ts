export declare class Counterparty {
    id: number;
    name: string;
}
