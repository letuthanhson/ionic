import { Counterparty } from './counterparty';
export declare class RankedCounterparty extends Counterparty {
    rank: number;
    parentId: number;
    rootId: number;
}
