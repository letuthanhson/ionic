export declare class CounterpartyFile {
    url: string;
    name: string;
}
