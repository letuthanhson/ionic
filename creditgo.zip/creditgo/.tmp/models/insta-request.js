export var InstaRequest = (function () {
    function InstaRequest(route, userId, jsonRequest) {
        this.source = "InstaCredit";
        this.route = route;
        this.userId = userId;
        this.jsonRequest = jsonRequest;
    }
    return InstaRequest;
}());
