export declare class LogonUser {
    userid: string;
    password: string;
    rememberMe: boolean;
}
