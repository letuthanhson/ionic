export class CounterpartyFile {
    url: string;
    name: string;
}