import { Platform, NavController, Events } from 'ionic-angular';
import { Idle } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { TabsPage } from '../pages/tabs/tabs';
export declare class MyApp {
    private idle;
    private keepalive;
    private events;
    nav: NavController;
    rootPage: typeof TabsPage;
    constructor(platform: Platform, idle: Idle, keepalive: Keepalive, events: Events);
    reset(): void;
}
