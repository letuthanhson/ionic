import { Component, ViewChild } from '@angular/core';
import { Platform, Events } from 'ionic-angular';
import { StatusBar, Splashscreen } from 'ionic-native';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { TabsPage } from '../pages/tabs/tabs';
export var MyApp = (function () {
    //idleState = 'Not started.';
    //timedOut = false;
    //lastPing?: Date = null;
    function MyApp(platform, idle, keepalive, events) {
        var _this = this;
        this.idle = idle;
        this.keepalive = keepalive;
        this.events = events;
        this.rootPage = TabsPage;
        platform.ready().then(function () {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            StatusBar.styleDefault();
            Splashscreen.hide();
        });
        this.events.subscribe('user:signedIn', function (data) {
            _this.reset();
        });
        // sets an idle timeout of 5 seconds, for testing purposes.
        this.idle.setIdle(10);
        // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
        this.idle.setTimeout(1200);
        // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
        this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
        // this.idle.onIdleStart.subscribe(() => {this.idleState = 'You\'ve gone idle!';console.log(this.idleState);});
        // this.idle.onTimeoutWarning.subscribe((countdown) => {
        //   this.idleState = 'You will time out in ' + countdown + ' seconds!';
        //   console.log(this.idleState);
        // });
        this.idle.onTimeout.subscribe(function () {
            //this.idleState = 'Timed out!';
            //this.timedOut = true;
            _this.nav.popToRoot().then(function (c) {
                _this.nav.setRoot(TabsPage);
            });
        });
        //this.reset();
    }
    MyApp.prototype.reset = function () {
        this.idle.watch();
        //this.idleState = 'Started.';
        //this.timedOut = false;
    };
    MyApp.decorators = [
        { type: Component, args: [{
                    template: "<ion-nav #myNav [root]=\"rootPage\"></ion-nav>"
                },] },
    ];
    /** @nocollapse */
    MyApp.ctorParameters = [
        { type: Platform, },
        { type: Idle, },
        { type: Keepalive, },
        { type: Events, },
    ];
    MyApp.propDecorators = {
        'nav': [{ type: ViewChild, args: ['myNav',] },],
    };
    return MyApp;
}());
