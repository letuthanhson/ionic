import { Component, ViewChild } from '@angular/core';
import { Platform, NavController, LoadingController, AlertController, ModalController } from 'ionic-angular';
import { ChartModalPage } from '../chart-modal/chart-modal';
import { InstaService } from '../../services/insta-service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/observable/forkJoin';
export var DashboardPage = (function () {
    function DashboardPage(platform, navCtrl, modalCtrl, instaService, alertCtrl, loadingCtrl) {
        var _this = this;
        this.platform = platform;
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.instaService = instaService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.isDataLoaded = false;
        this.orientationChange = function (event) {
            _this.setFabPosition();
            _this.renderBubbleChart();
        };
    }
    DashboardPage.prototype.ionViewDidLoad = function () {
        this.setFabPosition();
    };
    DashboardPage.prototype.setFabPosition = function () {
        console.log("inner width:" + window.innerWidth);
        if (window.orientation === 90 || window.orientation === -90 || window.innerWidth > 767) {
            $('#chartExpandTeam').removeAttr("right");
            $('#chartExpandTeam').attr("center", "");
        }
        else {
            $('#chartExpandTeam').removeAttr("center");
            $('#chartExpandTeam').attr("right", "");
        }
    };
    DashboardPage.prototype.ionViewDidEnter = function () {
        // add orientation change event handler
        window.addEventListener("orientationchange", this.orientationChange, false);
    };
    DashboardPage.prototype.ionViewDidLeave = function () {
        window.removeEventListener("orientationchange", this.orientationChange, false);
    };
    DashboardPage.prototype.renderBubbleChart = function () {
        // loading rating band data
        var root = {};
        root.name = "Interactions";
        root.children = new Array();
        this.ratingBandExposuresAndExpectedLosses.map(function (o) {
            root.children.push({ name: o.ratingBand, value: o.exposure });
        });
        this.chartRatingBandExposures.render(root);
    };
    DashboardPage.prototype.zoomInChartRatingBand = function () {
        var root = {};
        root.name = "Interactions";
        root.children = new Array();
        this.ratingBandExposuresAndExpectedLosses.map(function (o) {
            root.children.push({ name: o.ratingBand, value: o.exposure });
        });
        //let modal = this.modalCtrl.create(ChartModalPage, { "bubbleRootData": root, "bubbleChartTitle": "Exposures By Rating Band" });
        //modal.present();
    };
    DashboardPage.prototype.zoomInChartTeam = function () {
        var chartData = this.chartDataExposuresAndExpectedLosses(DashboardPage.TEAM, this.teamExposuresAndExpectedLosses);
        //let modal = this.modalCtrl.create(ChartModalPage, { "chartData": chartData });
        //modal.present();
        this.navCtrl.push(ChartModalPage, { "chartData": chartData, "maximize": true });
    };
    DashboardPage.prototype.zoomInChartHistorical = function () {
        var chartData = this.chartDataHistoricalExposuresAndExpectedLosses(this.historialExposuresAndExpectedLosses);
        //let modal = this.modalCtrl.create(ChartModalPage, { "chartData": chartData });
        //modal.present();
        this.navCtrl.push(ChartModalPage, { "chartData": chartData });
    };
    DashboardPage.prototype.ngOnInit = function () {
        var loading = this.loadingCtrl.create({
            content: 'please wait'
        });
        loading.present();
        this.getAllDashboardData(function () { return loading.dismissAll(); });
        //this.showHistoricalExposuresAndExpectedLosses();
        //this.showRatingBandExposuresAndExpectedLosses();
        //this.showTeamExposuresAndExpectedLosses();
    };
    // refresh hanlder
    DashboardPage.prototype.refreshDashboard = function (refresher) {
        this.getAllDashboardData(function () { return refresher.complete(); });
    };
    // get all dashboard data
    // call back for UI to release any object
    DashboardPage.prototype.getAllDashboardData = function (callback) {
        var _this = this;
        Observable.forkJoin(this.instaService.getHistoricalExposuresAndExpectedLosses(), this.instaService.getExposuresAndLimitsGroupByRatingBand(), this.instaService.getExposuresAndLimitsGroupByTeam())
            .subscribe(function (data) {
            _this.historialExposuresAndExpectedLosses = data[0];
            _this.ratingBandExposuresAndExpectedLosses = data[1];
            _this.teamExposuresAndExpectedLosses = data[2];
            if (callback)
                callback();
            _this.renderAllCharts();
            _this.isDataLoaded = true;
        }, function (error) {
            if (callback)
                callback();
            var alert = _this.alertCtrl.create({
                title: 'Loading Error!',
                subTitle: 'Failed to load dashboard data',
                buttons: ['OK']
            });
            alert.present();
        });
    };
    DashboardPage.prototype.renderAllCharts = function () {
        //todo: remove this function
        this.setFabPosition();
        // loading rating band data
        var root = {};
        root.name = "Interactions";
        root.children = new Array();
        this.ratingBandExposuresAndExpectedLosses.map(function (o) {
            root.children.push({ name: o.ratingBand, value: o.exposure });
        });
        this.chartRatingBandExposures.render(root);
        // loading historical data
        this.chartHistoricalExposures.render(this.chartDataHistoricalExposuresAndExpectedLosses(this.historialExposuresAndExpectedLosses));
        this.chartTeamExposures.render(this.chartDataExposuresAndExpectedLosses(DashboardPage.TEAM, this.teamExposuresAndExpectedLosses));
    };
    DashboardPage.prototype.randomCssRgba = function () {
        var rgbaArray = [this.randomNumber(0, 255), this.randomNumber(0, 255), this.randomNumber(0, 255), this.randomNumber(50, 100) * 0.01];
        return 'rgba(' + rgbaArray.join(',') + ')';
    };
    DashboardPage.prototype.randomNumber = function (min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    };
    DashboardPage.prototype.chartDataExposuresAndExpectedLosses = function (category, exposuresAndLosses) {
        var categories = [];
        if (category == DashboardPage.RATING_BAND) {
            categories = exposuresAndLosses.map(function (o) {
                return o.ratingBand;
            });
        }
        else if (category == DashboardPage.TEAM) {
            categories = exposuresAndLosses.map(function (o) {
                return o.teamName;
            });
        }
        else
            return {}; // no chart data
        var exposures = exposuresAndLosses.map(function (o) {
            return Math.round(o.exposure);
        });
        var expectedLosses = exposuresAndLosses.map(function (o) {
            return Math.round(o.expectedLoss);
        });
        return {
            chart: {
                type: 'bar',
                spacingBottom: 50,
                spacingRight: 50
            },
            title: {
                text: 'Exposures & Expected Losses By ' + category
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: categories,
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'USD',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                valueSuffix: ''
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: false
                    }
                }
            },
            credits: {
                enabled: false
            },
            series: [{
                    color: '#FF6600',
                    name: 'Exposures',
                    data: exposures
                }, {
                    color: '#000000',
                    name: 'Expected Losses',
                    data: expectedLosses
                }]
        };
    };
    // gets historical chartdata for historical and expected losses
    DashboardPage.prototype.chartDataHistoricalExposuresAndExpectedLosses = function (exposuresAndLosses) {
        var exposurePoints = exposuresAndLosses.map(function (o) {
            return [(new Date(o.exposureDate)).getTime(), o.exposure];
        });
        return {
            chart: {
                spacingRight: 50
            },
            title: {
                text: 'Historical Exposures'
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                type: 'datetime',
                dateTimeLabelFormats: {
                    day: '%e %b <br/> %Y',
                    month: '%e %b <br/> %Y',
                    year: '%e %b <br/> %Y'
                },
                title: {
                    text: 'Date'
                }
            },
            yAxis: {
                title: {
                    text: 'USD'
                },
                min: 0
            },
            credits: {
                enabled: false
            },
            tooltip: {
                headerFormat: '<b>{series.name}</b><br>',
                pointFormat: '{point.x:%e-%b-%y}: {point.y:,.0f}'
            },
            plotOptions: {
                spline: {
                    marker: {
                        enabled: true
                    }
                }
            },
            series: [{
                    color: '#FF6600',
                    name: 'Exposures',
                    data: exposurePoints
                }]
        };
    };
    DashboardPage.RATING_BAND = 'Rating Band';
    DashboardPage.TEAM = 'Team';
    DashboardPage.decorators = [
        { type: Component, args: [{
                    templateUrl: 'dashboard.html'
                },] },
    ];
    /** @nocollapse */
    DashboardPage.ctorParameters = [
        { type: Platform, },
        { type: NavController, },
        { type: ModalController, },
        { type: InstaService, },
        { type: AlertController, },
        { type: LoadingController, },
    ];
    DashboardPage.propDecorators = {
        'chartRatingBandExposures': [{ type: ViewChild, args: ['chartRatingBandExposures',] },],
        'chartHistoricalExposures': [{ type: ViewChild, args: ['chartHistoricalExposures',] },],
        'chartTeamExposures': [{ type: ViewChild, args: ['chartTeamExposures',] },],
    };
    return DashboardPage;
}());
