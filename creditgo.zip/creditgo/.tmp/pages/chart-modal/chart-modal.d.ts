import { NavController, Platform, NavParams } from 'ionic-angular';
import { BubbleChartComponent } from '../../components/bubble-chart/bubble-chart';
export declare class ChartModalPage {
    platform: Platform;
    params: NavParams;
    navCtrl: NavController;
    bubbleChart: BubbleChartComponent;
    highChartsData: any;
    bubbleRootData: any;
    bubbleChartTitle: string;
    constructor(platform: Platform, params: NavParams, navCtrl: NavController);
    ionViewDidLoad(): void;
    ionViewWillUnload(): void;
    ionViewDidEnter(): void;
    orientationChange: (event: any) => void;
    ionViewDidLeave(): void;
    dismiss(): void;
}
