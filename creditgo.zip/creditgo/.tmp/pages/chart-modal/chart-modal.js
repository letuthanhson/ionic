import { Component, ViewChild } from '@angular/core';
import { NavController, Platform, NavParams } from 'ionic-angular';
export var ChartModalPage = (function () {
    function ChartModalPage(platform, params, navCtrl) {
        this.platform = platform;
        this.params = params;
        this.navCtrl = navCtrl;
        this.orientationChange = function (event) {
            $('#the-chart').highcharts().setSize(null, window.innerHeight - 60, false);
        };
        // bubble chart
        if (params.get('bubbleRootData') != undefined)
            this.bubbleRootData = params.get('bubbleRootData');
        if (params.get('bubbleChartTitle') != undefined)
            this.bubbleChartTitle = params.get('bubbleChartTitle');
        // highcharts
        if (params.get('chartData') != undefined)
            this.highChartsData = params.get('chartData');
        if (params.get('title') != undefined)
            this.highChartsData.title = { text: params.get('title') };
        if (params.get('subtitle') != undefined)
            this.highChartsData.subtitle = { text: params.get('subtitle') };
    }
    ChartModalPage.prototype.ionViewDidLoad = function () {
    };
    ChartModalPage.prototype.ionViewWillUnload = function () {
        // remove zoom type on unload 
        this.highChartsData.chart.zoomType = '';
        //ScreenOrientation.unlockOrientation();
    };
    ChartModalPage.prototype.ionViewDidEnter = function () {
        //ScreenOrientation.lockOrientation('landscape');
        if (this.highChartsData != undefined) {
            // add zoom type on max
            this.highChartsData.chart.zoomType = 'xy';
            $('#the-chart').highcharts(this.highChartsData);
            //if(window.orientation === 90|| window.orientation === -90)
            $('#the-chart').highcharts().setSize(null, window.innerHeight - 60, false);
        }
        if (this.bubbleRootData != undefined)
            this.bubbleChart.render(this.bubbleRootData);
        // add orientation change event handler
        window.addEventListener("orientationchange", this.orientationChange, false);
    };
    ChartModalPage.prototype.ionViewDidLeave = function () {
        // right now just call render chart blindly
        // will look into detect when orientation changed
        var prevPage = this.navCtrl.getPrevious().instance;
        if (prevPage.renderAllCharts !== undefined)
            prevPage.renderAllCharts();
        // add orientation change event handler
        window.removeEventListener("orientationchange", this.orientationChange, false);
    };
    ChartModalPage.prototype.dismiss = function () {
        this.navCtrl.pop();
    };
    ChartModalPage.decorators = [
        { type: Component, args: [{
                    templateUrl: 'chart-modal.html'
                },] },
    ];
    /** @nocollapse */
    ChartModalPage.ctorParameters = [
        { type: Platform, },
        { type: NavParams, },
        { type: NavController, },
    ];
    ChartModalPage.propDecorators = {
        'bubbleChart': [{ type: ViewChild, args: ['bubbleChart',] },],
    };
    return ChartModalPage;
}());
