import { Component, ViewChild } from '@angular/core';
import { App, NavController, AlertController, ToastController, PopoverController, LoadingController, ViewController, NavParams, ActionSheetController, ModalController } from 'ionic-angular';
import { CounterpartyService } from '../../services/counterparty-service';
import { InstaService } from '../../services/insta-service';
import { CounterpartyCaPage } from '../counterparty-ca/counterparty-ca';
import { ChartModalPage } from '../chart-modal/chart-modal';
import { Observable } from 'rxjs/Observable';
export var CounterpartyInfoPage = (function () {
    function CounterpartyInfoPage(navCtrl, app, instaService, popoverCtrl, actionSheetCtrl, modalCtrl, counterpartyService, alertCtrl, loadingCtrl, toastController, navParams) {
        this.navCtrl = navCtrl;
        this.app = app;
        this.instaService = instaService;
        this.popoverCtrl = popoverCtrl;
        this.actionSheetCtrl = actionSheetCtrl;
        this.modalCtrl = modalCtrl;
        this.counterpartyService = counterpartyService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.toastController = toastController;
        // If we navigated to this page, we will have an item available as a nav param
        this.cpInfo = navParams.get('counterpartyInfo');
        this.limitsAndExposures = navParams.get('limitsAndExposures');
        console.log(this.cpInfo);
        console.log(this.limitsAndExposures);
    }
    CounterpartyInfoPage.prototype.ngOnInit = function () {
        this.showLimitsAndExposures();
    };
    // refresh handler
    CounterpartyInfoPage.prototype.refreshCounterpartyInfo = function (refresher) {
        var _this = this;
        Observable
            .forkJoin(this.instaService.getCounterpartyDetail(this.cpInfo.id), this.instaService.getCounterpartyCurrentLimitsAndExposures(this.cpInfo.name))
            .subscribe(function (data) {
            _this.cpInfo = data[0];
            _this.limitsAndExposures = data[1];
            _this.showLimitsAndExposures();
            refresher.complete();
        });
    };
    CounterpartyInfoPage.prototype.showLimitsAndExposures = function () {
        if (this.limitsAndExposures === undefined)
            return;
        var limitPoints = this.limitsAndExposures.map(function (o) {
            return [(new Date(o.exposureDate)).getTime(), o.limit];
        });
        var exposurePoints = this.limitsAndExposures.map(function (o) {
            return [(new Date(o.exposureDate)).getTime(), o.currentExposure];
        });
        this.chartLimitsAndExposureData = this.getLimitsExposuresChartData(limitPoints, exposurePoints);
        this.chartLimitsAndExposures.render(this.chartLimitsAndExposureData);
    };
    CounterpartyInfoPage.prototype.showCaFiles = function () {
        var _this = this;
        console.log("Getting CA files...");
        this.caFileList = undefined;
        var loading = this.loadingCtrl.create({
            content: 'please wait'
        });
        loading.present();
        this.instaService.getCounterpartyCaFiles(this.cpInfo.id)
            .subscribe(function (data) {
            loading.dismissAll();
            _this.caFileList = data;
            if (_this.caFileList === undefined || _this.caFileList.length === 0) {
                var toast = _this.toastController.create({
                    message: 'Credit Review documents are not available for the counterparty',
                    duration: 3000,
                    position: 'middle'
                });
                toast.present();
            }
            else {
                //this.showCaActionSheet();  //For this version there is only Action Items.  Let's go directly
                //open the list of documents for the cp
                _this.navCtrl.push(CounterpartyCaPage, { "counterpartyName": _this.cpInfo.name, "documents": _this.caFileList });
            }
        }, function (error) {
            loading.dismissAll();
            console.log(error);
            var alert = _this.alertCtrl.create({
                title: 'Loading Error!',
                subTitle: 'Failed to load data',
                buttons: ['OK']
            });
            alert.present();
        });
    };
    CounterpartyInfoPage.prototype.showCaActionSheet = function () {
        var _this = this;
        if (this.caFileList === undefined && this.caFileList.length == 0)
            return;
        var actionSheet = this.actionSheetCtrl.create({
            title: this.cpInfo.name,
            buttons: [{
                    text: 'Credit Reviews',
                    handler: function () {
                        var navTransition = actionSheet.dismiss();
                        navTransition.then(function () {
                            //open the list of documents for the cp
                            _this.navCtrl.push(CounterpartyCaPage, { "counterpartyName": _this.cpInfo.name, "documents": _this.caFileList });
                        });
                        return false;
                    }
                }, {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: function () {
                        ;
                    }
                }]
        });
        actionSheet.present();
    };
    CounterpartyInfoPage.prototype.getLimitsExposuresChartData = function (limits, exposures) {
        return {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: 'Exposures & Limits'
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                type: 'datetime',
                dateTimeLabelFormats: {
                    day: '%e %b <br/> %Y',
                    month: '%e %b <br/> %Y',
                    year: '%e %b <br/> %Y'
                },
                title: {
                    text: 'Date'
                }
            },
            yAxis: {
                title: {
                    text: 'USD'
                },
                min: 0
            },
            credits: {
                enabled: false
            },
            tooltip: {
                headerFormat: '<b>{series.name}</b><br>',
                pointFormat: '{point.x:%e-%b-%y}: {point.y:,.0f}'
            },
            plotOptions: {
                spline: {
                    marker: {
                        enabled: true
                    }
                }
            },
            series: [{
                    //step: true,
                    color: '#006633',
                    name: 'Limits',
                    data: limits
                }, {
                    //step: true,
                    color: '#FF6600',
                    name: 'Exposures',
                    data: exposures
                }]
        };
    };
    //open Chart in full screen
    CounterpartyInfoPage.prototype.zoomInChartLimitsAndExposures = function () {
        // Get the same chart data on this page and set title
        /*
            let chartData = this.chartLimitsAndExposureData;
            chartData.title = { text: this.cpInfo.name };
            chartData.subtitle = { text: 'Limits & Exposures'};
        
            this.app.getRootNav().push(OnlyChartPage, { "chartData": chartData });
        
            */
        var chartData = this.chartLimitsAndExposureData;
        //let modal = this.modalCtrl.create(ChartModalPage, { "chartData": chartData, "title": this.cpInfo.name, "subtitle": "Limits  & Exposures" });
        //modal.onDidDismiss(()=>{});
        this.navCtrl.push(ChartModalPage, { "chartData": chartData, "title": this.cpInfo.name, "subtitle": "Limits  & Exposures" });
        //modal.present();
    };
    CounterpartyInfoPage.prototype.renderAllCharts = function () {
        this.chartLimitsAndExposures.render(this.chartLimitsAndExposureData);
    };
    CounterpartyInfoPage.decorators = [
        { type: Component, args: [{
                    templateUrl: 'counterparty-info.html',
                    providers: [CounterpartyService]
                },] },
    ];
    /** @nocollapse */
    CounterpartyInfoPage.ctorParameters = [
        { type: NavController, },
        { type: App, },
        { type: InstaService, },
        { type: PopoverController, },
        { type: ActionSheetController, },
        { type: ModalController, },
        { type: CounterpartyService, },
        { type: AlertController, },
        { type: LoadingController, },
        { type: ToastController, },
        { type: NavParams, },
    ];
    CounterpartyInfoPage.propDecorators = {
        'chartLimitsAndExposures': [{ type: ViewChild, args: ['chartLimitsAndExposures',] },],
    };
    return CounterpartyInfoPage;
}());
var PopoverMenu = (function () {
    function PopoverMenu(viewCtrl, navCtrl, navParams) {
        this.viewCtrl = viewCtrl;
        this.navCtrl = navCtrl;
        this.counterpartyName = navParams.get('counterpartyName');
        this.documents = navParams.get('documents');
    }
    PopoverMenu.prototype.openCaDocuments = function () {
        var _this = this;
        this.navCtrl.push(CounterpartyCaPage, { "counterpartyName": this.counterpartyName, "documents": this.documents }).then(function () {
            _this.viewCtrl.dismiss();
        });
    };
    PopoverMenu.prototype.openAlerts = function () {
        /*
            this.navCtrl.push(DashboardPage).then(()=>{
              this.viewCtrl.dismiss();});
              */
    };
    PopoverMenu.decorators = [
        { type: Component, args: [{
                    template: "\n    <ion-list>\n      <ion-list-header>InstaCredit</ion-list-header>\n      <button ion-item (click)=\"openCaDocuments()\">Credit Reviews</button>\n      <button ion-item (click)=\"openAlerts()\">Credit Alerts</button>\n    </ion-list>\n  "
                },] },
    ];
    /** @nocollapse */
    PopoverMenu.ctorParameters = [
        { type: ViewController, },
        { type: NavController, },
        { type: NavParams, },
    ];
    return PopoverMenu;
}());
