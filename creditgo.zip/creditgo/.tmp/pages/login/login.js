import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { SecureStorage, TouchID } from 'ionic-native';
import { AlertController, Events, LoadingController, NavController, NavParams, Platform, ViewController } from 'ionic-angular';
import { LogonUser } from '../../models/logon-user';
import { InstaService } from '../../services/insta-service';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
export var LoginPage = (function () {
    function LoginPage(platform, nav, viewCtrl, formBuilder, instaService, alertCtrl, loadingCtrl, navParams, events) {
        var _this = this;
        this.platform = platform;
        this.nav = nav;
        this.viewCtrl = viewCtrl;
        this.formBuilder = formBuilder;
        this.instaService = instaService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.navParams = navParams;
        this.events = events;
        this.logonUser = new LogonUser();
        this.touchIdPwd = "";
        this.logonUser = this.navParams.get('logonUser');
        this.baseServiceUrl = this.navParams.get('baseServiceUrl');
        this.touchIdPwd = this.logonUser.password;
        this.userForm = this.formBuilder.group({
            "userid": [this.logonUser.userid, Validators.required],
            "password": [this.logonUser.password, Validators.required],
            "rememberMe": [this.logonUser.rememberMe]
        });
        this.platform.ready().then(function () {
            TouchID.isAvailable().then(function (res) {
                _this.touchIdAvailable = true;
                _this.userForm.controls['password'].setValue("");
                // show touch id when remember is set up and touchid available
                if (_this.logonUser.rememberMe) {
                    _this.startTouchID();
                }
            }, function (err) { return _this.touchIdAvailable = false; });
        });
    }
    LoginPage.prototype.startTouchID = function () {
        var _this = this;
        TouchID.verifyFingerprint('Login with Touch ID')
            .then(function (res) { return _this.loginWithTouchID(); }, function (err) { return console.error('Error', err); });
    };
    LoginPage.prototype.rememberMe = function (rememberUser) {
        var secureStorage = new SecureStorage();
        secureStorage.create('account_safe')
            .then(function () {
            console.log('Secure Storage is ready!');
            secureStorage.set('loginInfo', JSON.stringify(rememberUser))
                .then(function (data) {
                console.log("Remembering user successfully");
            }, function (error) {
                console.log("Failed to remember user");
            });
        }).catch(function (e) { return console.log(e); });
    };
    LoginPage.prototype.loginWithTouchID = function () {
        this.userForm.value.password = this.touchIdPwd;
        this.login();
    };
    LoginPage.prototype.login = function () {
        var _this = this;
        // login
        this.logonUser = this.userForm.value;
        // remember me
        this.rememberMe(this.logonUser);
        var loading = this.loadingCtrl.create({
            content: 'please wait'
        });
        loading.present();
        this.instaService.setServiceCredential(this.baseServiceUrl, 
        //"/api/InstaCredit_External/proxy?wsdl",
        this.logonUser.userid, this.logonUser.password);
        this.instaService.authenticate()
            .subscribe(function () {
            // authenticate successfully
            console.log("Authenticating successfully...");
            _this.viewCtrl.dismiss();
            loading.dismissAll();
            _this.events.publish('user:signedIn', 'login');
        }, function (error) {
            loading.dismissAll();
            var alert = _this.alertCtrl.create({
                title: 'Login Error!',
                subTitle: 'Login failed!',
                buttons: ['OK']
            });
            alert.present();
        });
    };
    LoginPage.SS = "app_storage";
    LoginPage.SS_USER_KEY = "logonUser";
    LoginPage.decorators = [
        { type: Component, args: [{
                    selector: 'page-login',
                    templateUrl: 'login.html'
                },] },
    ];
    /** @nocollapse */
    LoginPage.ctorParameters = [
        { type: Platform, },
        { type: NavController, },
        { type: ViewController, },
        { type: FormBuilder, },
        { type: InstaService, },
        { type: AlertController, },
        { type: LoadingController, },
        { type: NavParams, },
        { type: Events, },
    ];
    return LoginPage;
}());
