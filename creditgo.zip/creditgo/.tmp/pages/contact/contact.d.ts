import { NavController } from 'ionic-angular';
export declare class ContactPage {
    navCtrl: NavController;
    constructor(navCtrl: NavController);
}
