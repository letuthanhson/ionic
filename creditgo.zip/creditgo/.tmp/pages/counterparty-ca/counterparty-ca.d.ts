import { OnInit } from '@angular/core';
import { NavController, LoadingController, AlertController, ToastController, NavParams } from 'ionic-angular';
import { InstaService } from '../../services/insta-service';
export declare class CounterpartyCaPage implements OnInit {
    private navCtrl;
    private instaService;
    private alertCtrl;
    private loadingCtrl;
    private toastController;
    counterpartyName: string;
    documents: any[];
    constructor(navCtrl: NavController, instaService: InstaService, alertCtrl: AlertController, loadingCtrl: LoadingController, toastController: ToastController, navParams: NavParams);
    ngOnInit(): void;
    openDoc(item: any): void;
    openDocument(fileName: string, contentType: string, contentAsBase64: string): void;
}
