import { Component } from '@angular/core';
import { NavController, LoadingController, AlertController, ToastController, NavParams } from 'ionic-angular';
import { InstaService } from '../../services/insta-service';
export var CounterpartyCaPage = (function () {
    function CounterpartyCaPage(navCtrl, instaService, alertCtrl, loadingCtrl, toastController, navParams) {
        this.navCtrl = navCtrl;
        this.instaService = instaService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.toastController = toastController;
        // If we navigated to this page, we will have an item available as a nav param
        this.counterpartyName = navParams.get('counterpartyName');
        this.documents = navParams.get('documents');
        //console.log(this.counterpartyName);
        //console.log(this.documents);
    }
    CounterpartyCaPage.prototype.ngOnInit = function () {
    };
    CounterpartyCaPage.prototype.openDoc = function (item) {
        var _this = this;
        var loading = this.loadingCtrl.create({
            content: 'please wait'
        });
        loading.present();
        this.instaService.getCounterpartyCaFileBase64(item.url)
            .subscribe(function (data) {
            loading.dismissAll();
            if (data === undefined && data.fileasbase64 == undefined) {
                var toast = _this.toastController.create({
                    message: 'Unable to get file content',
                    duration: 3000,
                    position: 'middle'
                });
                toast.present();
            }
            else {
                _this.openDocument(item.name, data.mimeType, data.fileAsBase64);
            }
        }, function (error) {
            loading.dismissAll();
            console.log(error);
            var alert = _this.alertCtrl.create({
                title: 'Loading Error!',
                subTitle: 'Failed to load the document',
                buttons: ['OK']
            });
            alert.present();
        });
    };
    CounterpartyCaPage.prototype.openDocument = function (fileName, contentType, contentAsBase64) {
        console.log("open file dir/file/content type..."
            + cordova.file.dataDirectory + ':' + fileName + ':' + contentType);
        fileName = fileName.replace(/\s+/g, '');
        DocumentHandler.saveAndPreviewBase64File(function (success) { }, function (error) {
            console.log("Error", JSON.stringify(error));
            var errorMsg = '';
            if (error == 53)
                errorMsg = 'No application handles this file type';
            else
                errorMsg = 'Unable to open file';
            var alert = this.alertCtrl.create({
                title: 'File Openning Error!',
                subTitle: errorMsg,
                buttons: ['OK']
            });
            console.log("Alert Object: " + JSON.stringify(alert));
            alert.present();
        }, contentAsBase64, contentType, // 'application/pdf', 
        cordova.file.dataDirectory, fileName);
    };
    CounterpartyCaPage.decorators = [
        { type: Component, args: [{
                    templateUrl: 'counterparty-ca.html'
                },] },
    ];
    /** @nocollapse */
    CounterpartyCaPage.ctorParameters = [
        { type: NavController, },
        { type: InstaService, },
        { type: AlertController, },
        { type: LoadingController, },
        { type: ToastController, },
        { type: NavParams, },
    ];
    return CounterpartyCaPage;
}());
