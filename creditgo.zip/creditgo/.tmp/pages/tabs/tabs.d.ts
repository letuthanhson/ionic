export declare class TabsPage {
    tab1Root: any;
    tab2Root: any;
    tab3Root: any;
    tab4Root: any;
    constructor();
}
