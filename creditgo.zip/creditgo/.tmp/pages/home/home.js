import { Component } from '@angular/core';
import { NavController, ModalController, Platform, AlertController, LoadingController } from 'ionic-angular';
import { SecureStorage } from 'ionic-native';
import { LoginPage } from '../login/login';
import { LogonUser } from '../../models/logon-user';
import { InstaService } from '../../services/insta-service';
export var HomePage = (function () {
    function HomePage(platform, navCtrl, modalCtrl, instaService, alertCtrl, loadingCtrl) {
        var _this = this;
        this.platform = platform;
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.instaService = instaService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        platform.ready().then(function () {
            // Get baseServiceUrl
            var loading = _this.loadingCtrl.create({
                content: ''
            });
            loading.present();
            _this.instaService.getAppConfig()
                .subscribe(function (data) {
                loading.dismissAll();
                var url = data.serviceBaseUrl;
                console.log('Service end-point: ' + url);
                if (url === undefined) {
                    var alert_1 = _this.alertCtrl.create({
                        title: 'Fatal Error!',
                        subTitle: 'Unable to get configuration for service end-point.  Please contact admin.',
                        buttons: ['OK']
                    });
                    alert_1.present();
                    platform.exitApp();
                }
                else
                    _this.startLogin(url);
            }, function (error) {
                loading.dismissAll();
                console.log(error);
                var alert = _this.alertCtrl.create({
                    title: 'Fatal Error!',
                    subTitle: 'Unable to get service end-point.  Please contact admin.',
                    buttons: ['OK']
                });
                alert.present();
                platform.exitApp();
            });
            /*
                      NativeStorage.getItem(LoginPage.SS_USER_KEY)
                        .then(data  => {
                            let savedUser: LogonUser = data;
                            if (savedUser != undefined && savedUser.rememberMe)
                              this.showLoginPage(savedUser);
                            else
                              this.showLoginPage(new LogonUser());
                        },
                        error => {
                          // do nothing - no data
                          this.showLoginPage(new LogonUser());
                        });
            */
        }).catch(function (e) {
            var alert = _this.alertCtrl.create({
                title: 'Fatal Error!',
                subTitle: 'Unable to get service end-point.  Please contact admin.',
                buttons: ['OK']
            });
            alert.present();
            platform.exitApp();
        });
    }
    HomePage.prototype.showLoginPage = function (savedUser, baseServiceUrl) {
        var profileModal = this.modalCtrl.create(LoginPage, { "logonUser": savedUser, "baseServiceUrl": baseServiceUrl }, { enableBackdropDismiss: false });
        profileModal.present();
    };
    HomePage.prototype.startLogin = function (baseServiceUrl) {
        var _this = this;
        var secureStorage = new SecureStorage();
        secureStorage.create('account_safe')
            .then(function () {
            console.log('Secure Storage is ready!');
            secureStorage.get('loginInfo')
                .then(function (data) {
                var savedUser = JSON.parse(data);
                if (savedUser != undefined && savedUser.rememberMe)
                    _this.showLoginPage(savedUser, baseServiceUrl);
                else
                    _this.showLoginPage(new LogonUser(), baseServiceUrl);
            }, function (error) {
                // nothing saved previously
                _this.showLoginPage(new LogonUser(), baseServiceUrl);
            });
        })
            .catch(function (e) {
            console.log(e);
            _this.showLoginPage(new LogonUser(), baseServiceUrl);
        });
    };
    HomePage.decorators = [
        { type: Component, args: [{
                    selector: 'page-home',
                    templateUrl: 'home.html'
                },] },
    ];
    /** @nocollapse */
    HomePage.ctorParameters = [
        { type: Platform, },
        { type: NavController, },
        { type: ModalController, },
        { type: InstaService, },
        { type: AlertController, },
        { type: LoadingController, },
    ];
    return HomePage;
}());
