import { NavController, ModalController, Platform, AlertController, LoadingController } from 'ionic-angular';
import { LogonUser } from '../../models/logon-user';
import { InstaService } from '../../services/insta-service';
export declare class HomePage {
    platform: Platform;
    navCtrl: NavController;
    modalCtrl: ModalController;
    private instaService;
    private alertCtrl;
    private loadingCtrl;
    constructor(platform: Platform, navCtrl: NavController, modalCtrl: ModalController, instaService: InstaService, alertCtrl: AlertController, loadingCtrl: LoadingController);
    showLoginPage(savedUser: LogonUser, baseServiceUrl: string): void;
    startLogin(baseServiceUrl: string): void;
}
