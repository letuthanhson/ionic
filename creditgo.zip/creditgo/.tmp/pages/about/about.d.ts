import { NavController, Platform, AlertController } from 'ionic-angular';
import { Http } from '@angular/http';
export declare class AboutPage {
    private platform;
    private navCtrl;
    private http;
    private alertCtrl;
    notMsg: string;
    version: string;
    build: string;
    constructor(platform: Platform, navCtrl: NavController, http: Http, alertCtrl: AlertController);
    showHelp(): void;
}
