import { Component } from '@angular/core';
import { NavController, Platform, AlertController } from 'ionic-angular';
import { AppVersion } from 'ionic-native';
import { Http } from '@angular/http';
export var AboutPage = (function () {
    function AboutPage(platform, navCtrl, http, alertCtrl) {
        var _this = this;
        this.platform = platform;
        this.navCtrl = navCtrl;
        this.http = http;
        this.alertCtrl = alertCtrl;
        this.version = "1.0.0";
        this.build = "1";
        platform.ready().then(function () {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            AppVersion.getVersionNumber()
                .then(function (o) {
                _this.version = o;
                console.log(_this.version);
            });
            AppVersion.getVersionCode()
                .then(function (o) {
                _this.build = o;
                console.log(_this.build);
            });
        });
        /*
            this.db.openDatabase({
              name: 'data.db',
              location: 'default'
            }).then(() => {
                this.db.executeSql("create table if not exists Counterparty (id integer primary key, counterparty text)", {})
                .then(o => {
                  this.notMsg = "Table created";
                },
                  (e) => {
                    this.notMsg = "Failed to create table";
                    console.log("Unable creating table", e);
                })
            },
            (e) => {
                this.notMsg = "Failed to open table";
                console.log("Unable to open database", e);
            });
        */
    }
    AboutPage.prototype.showHelp = function () {
        var self = this;
        console.log(cordova.file.applicationDirectory + "www/help/usermanual.docx");
        DocumentHandler.previewFileFromUrlOrPath(function (success) { }, function (error) {
            console.log("Error", error);
            var errorMsg = '';
            if (error == 53)
                errorMsg = 'No application handles this file type';
            else
                errorMsg = 'Unable to open file';
            var alert = self.alertCtrl.create({
                title: 'File Openning Error!',
                subTitle: errorMsg,
                buttons: ['OK']
            });
            console.log("Alert Object: " + error);
            alert.present();
        }, cordova.file.applicationDirectory + "www/help/usermanual.docx", "usermanual.docx");
    };
    /*
    mockCounterpartyData() {
      this.http.get('mock/counterparties.json')
              .map(res => res.json())
              .subscribe(data => {
                
                for (let i=0; i < data.length; i++) {
                  console.log("data", data[i].name);
  
                  this.db.executeSql("insert into Counterparty (id, counterparty) select ?, ? where not exists (select 1 from Counterparty where id = ?)", [data[i].id, JSON.stringify(data[i]), data[i].id])
                  
                  .then(s=>{
                      this.notMsg = "Succeeded inserting " + data[i].name;
                    }
                    , e => {
                      this.notMsg = "Failed to insert " + data[i].name;
                      console.log("Error inserting data: " + JSON.stringify(e.err));
                    });
                }
                
              
        });
    }
    mockRankedCounterpartyData(){
      this.http.get('mock/counterparties.json')
              .map(res => res.json())
              .subscribe(data => {
                
                for (let i=0; i < data.length; i++) {
                  console.log("data", data[i].id);
                  this.db.executeSql("insert into Counterparty (id, counterparty) values (?, ?)", [data[i].id, JSON.stringify(data[i])])
                    .then(s=>{
                      this.notMsg = "Succeeded inserting " + data[i].name;
                    }
                    , e => {
                      this.notMsg = "Failed to insert " + data[i].name;
                      console.log("Error inserting data: " + JSON.stringify(e.err));
                    });
                }
        });
    }
    deleteMockCounterparty()
    {
      this.db.executeSql("delete from Counterparty",{})
        .then(s=>{
          this.notMsg = "Succeeded deleting data";
        }
        , e => {
          this.notMsg = "Failed to delete ";
          console.log("Error deleting data: " + JSON.stringify(e.err));
        });
  
    }
    getMockCounterparty()
    {
      
      this.storage.query("select * from Counterparty where id = ?", [3430])
          .then(o=>{
            for(let i=0; i<o.res.rows.length; i++){
              console.log("Retrieve: ", o.res.rows.item(i).counterparty);
            }
          })
        .catch(e=>{
          console.log("Error select cp: ", e);
        });
        
    }
    getMockCounterpartyCount()
    {
      this.storage.query("select count(1) from Counterparty")
          .then(o=>{
            for(let i=0; i<o.res.rows.length; i++){
              console.log("Total Cps: ", o.res.rows.item(i));
            }
          })
        .catch(e=>{
          console.log("Error select count: ", e);
        });
        
    }
    */
    AboutPage.decorators = [
        { type: Component, args: [{
                    selector: 'page-about',
                    templateUrl: 'about.html'
                },] },
    ];
    /** @nocollapse */
    AboutPage.ctorParameters = [
        { type: Platform, },
        { type: NavController, },
        { type: Http, },
        { type: AlertController, },
    ];
    return AboutPage;
}());
