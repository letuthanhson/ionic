import { FormControl } from '@angular/forms';
import { Component } from '@angular/core';
import { NavController, AlertController, ToastController, LoadingController } from 'ionic-angular';
import { CounterpartyService } from '../../services/counterparty-service';
import { CounterpartyInfoPage } from '../counterparty-info/counterparty-info';
import { Http } from '@angular/http';
import { InstaService } from '../../services/insta-service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/observable/empty';
import "rxjs/add/operator/debounceTime";
import "rxjs/add/operator/distinctUntilChanged";
import "rxjs/add/operator/switchMap";
import "rxjs/add/operator/finally";
import 'rxjs';
export var CounterpartySearchPage = (function () {
    function CounterpartySearchPage(navCtrl, http, counterpartyService, instaService, alertCtrl, loadingCtrl, toastController) {
        this.navCtrl = navCtrl;
        this.http = http;
        this.counterpartyService = counterpartyService;
        this.instaService = instaService;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.toastController = toastController;
        this.showingSection = false;
        this.searchToken = "";
        this.searchControl = new FormControl();
        this.searching = false;
        this.prevSearchToken = "";
    }
    CounterpartySearchPage.prototype.ionViewDidLoad = function () {
        var _this = this;
        this.searchControl.valueChanges.debounceTime(500)
            .distinctUntilChanged()
            .switchMap(function (searchControl) {
            return _this.instaService.getRankedCounterpartiesByNameQuery(_this.searchToken.trim())
                .finally(function () {
                _this.searching = false;
            });
        })
            .subscribe(function (c) {
            _this.counterparties = c;
            if (c.length > 0) {
                _this.showingSection = true;
            }
            else {
                var toast = _this.toastController
                    .create({
                    message: 'Search returns no counterparty',
                    duration: 2000,
                    position: 'middle'
                });
                toast.present();
                _this.showingSection = false;
            }
        });
    };
    CounterpartySearchPage.prototype.refreshSearch = function (refresher) {
        this.clearSearchResult();
        if (!this.isSearchTokenValid()) {
            refresher.complete();
            return;
        }
        this.searchCounterparties(function () { return refresher.complete(); });
    };
    CounterpartySearchPage.prototype.clearSearchResult = function () {
        // this.counterparties = null;
        this.showingSection = false;
    };
    CounterpartySearchPage.prototype.isSearchTokenValid = function () {
        return (this.searchToken !== undefined && this.searchToken.trim().length > 1);
    };
    CounterpartySearchPage.prototype.searchClick = function (event) {
        // this.clearSearchResult();
        // if(!this.isSearchTokenValid()) return;
        // let loading = this.loadingCtrl.create({
        //   content: 'please wait'
        // });
        // loading.present();
        // this.searchCounterparties(()=> loading.dismissAll());
        if (this.prevSearchToken == event.target.value || !this.isSearchTokenValid())
            return;
        this.searching = true;
        this.showingSection = false;
        this.prevSearchToken = event.target.value;
    };
    CounterpartySearchPage.prototype.searchCounterparties = function (callback) {
        var _this = this;
        this.instaService.getRankedCounterpartiesByNameQuery(this.searchToken.trim())
            .subscribe(function (data) {
            _this.counterparties = data;
            if (callback)
                callback();
            if (_this.counterparties === undefined || data.length === 0) {
                _this.showingSection = false;
                var toast = _this.toastController.create({
                    message: 'Search returns no counterparty',
                    duration: 2000,
                    position: 'middle'
                });
                toast.present();
            }
            else {
                _this.showingSection = true;
            }
        }, function (error) {
            if (callback)
                callback();
            console.log(error);
            var alert = _this.alertCtrl.create({
                title: 'Loading Error!',
                subTitle: 'Failed to retrieve data',
                buttons: ['OK']
            });
            alert.present();
        });
        ;
    };
    CounterpartySearchPage.prototype.itemTapped = function (event, counterparty) {
        var _this = this;
        //get counterparty details
        var loading = this.loadingCtrl.create({
            content: 'please wait'
        });
        loading.present();
        Observable.forkJoin(this.instaService.getCounterpartyDetail(counterparty.id), this.instaService.getCounterpartyCurrentLimitsAndExposures(counterparty.name))
            .subscribe(function (data) {
            loading.dismissAll();
            if (data[0] == undefined) {
                var toast = _this.toastController.create({
                    message: 'The selected counterparty info is not available',
                    duration: 3000,
                    position: 'middle'
                });
                toast.present();
            }
            else {
                _this.navCtrl.push(CounterpartyInfoPage, { "counterpartyInfo": data[0], "limitsAndExposures": data[1] });
            }
        }, function (error) {
            loading.dismissAll();
            console.log(error);
            var alert = _this.alertCtrl.create({
                title: 'Loading Error!',
                subTitle: 'Failed to retrieve data',
                buttons: ['OK']
            });
            alert.present();
        });
        /*
        let cp = this.getMockedCp();
        this.navCtrl.push(CounterpartyInfoPage, { "counterpartyInfo": cp });
        */
    };
    // getMockedCp():any{
    //   let a =   {
    //   "id": 1458,
    //   "name": "MARUBENI_GROUP",
    //   "parentName": null,
    //   "jurisdiction": null,
    //   "isOnAlert": false,
    //   "alertNotes": null,
    //   "industryClass": "Commercial",
    //   "appraisalCompletionDate": "2015-04-15T00:00:00",
    //   "nextAppraisalDueDate": "2016-04-30T00:00:00",
    //   "gcrAnalyst": "Beers,Joshua",
    //   "strategicCreditAnalyst": "Lo,Lily",
    //   "countryOfRisk": "Japan",
    //   "rbuOwner": "SINGAPORE",
    //   "fiscalYearEndDate": null,
    //   "isMonitored": true,
    //   "isWatched": false,
    //   "watchComments": null,
    //   "canProvideCollateral": false,
    //   "requiresBankLoi": true,
    //   "permitsEpfTrades": false,
    //   "bpRating": "BBB",
    //   "bpConfidenceLevel": "Average",
    //   "portfolioTag": null,
    //   "bpOutlook": "Stable",
    //   "riskLevel": "ALTERNATE CASE",
    //   "sppRating": null,
    //   "moodyRating": null,
    //   "fitchRating": null,
    //   "issuerSppRating": null,
    //   "issuerMoodyRating": null,
    //   "isuerFitchRating": null,
    //   "sppOutlook": null,
    //   "moodyOutlook": null,
    //   "fitchOutlook": null,
    //   "bpRatingInferred": "Actual",
    //   "industryInferred": "Actual",
    //   "inferredBpRatingCeId": 1458,
    //   "inferredIndustryCeId": 1458,
    //   "isPfeCounterparty": false,
    //   "creditLimit_0_6M": 0.0,
    //   "creditLimit_7_12M": 0.0,
    //   "creditLimit_13_24M": 0.0,
    //   "creditLimit_25M_Plus": 0.0,
    //   "creditLimitCurrency": null,
    //   "pfeComments": null
    // };
    // return a;
    // }
    CounterpartySearchPage.decorators = [
        { type: Component, args: [{
                    templateUrl: 'counterparty-search.html',
                    providers: [CounterpartyService]
                },] },
    ];
    /** @nocollapse */
    CounterpartySearchPage.ctorParameters = [
        { type: NavController, },
        { type: Http, },
        { type: CounterpartyService, },
        { type: InstaService, },
        { type: AlertController, },
        { type: LoadingController, },
        { type: ToastController, },
    ];
    return CounterpartySearchPage;
}());
