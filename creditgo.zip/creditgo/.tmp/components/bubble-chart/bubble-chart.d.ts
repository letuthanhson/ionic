import { ElementRef } from '@angular/core';
export declare class BubbleChartComponent {
    bubbleChart: ElementRef;
    constructor();
    render(root: any): void;
    private getTooltip(chartId);
    private randomCssRgba();
    private randomNumber(min, max);
    heatmapColors(root: any): any[];
}
