import { Component, ViewChild } from '@angular/core';
export var HighchartsChartComponent = (function () {
    function HighchartsChartComponent() {
    }
    // draw a bubble chart
    HighchartsChartComponent.prototype.render = function (chartData) {
        $(this.theChart.nativeElement).highcharts(chartData);
    };
    HighchartsChartComponent.prototype.createGuid = function () {
        return this.s4() + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4() + this.s4() + this.s4();
    };
    HighchartsChartComponent.prototype.s4 = function () {
        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
    };
    HighchartsChartComponent.decorators = [
        { type: Component, args: [{
                    selector: 'highcharts-chart',
                    template: "\n        <div #theChart style=\"width: 100%;\"></div>    \n    "
                },] },
    ];
    /** @nocollapse */
    HighchartsChartComponent.ctorParameters = [];
    HighchartsChartComponent.propDecorators = {
        'theChart': [{ type: ViewChild, args: ['theChart',] },],
    };
    return HighchartsChartComponent;
}());
