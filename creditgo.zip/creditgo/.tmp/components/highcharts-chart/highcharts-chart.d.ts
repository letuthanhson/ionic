import { ElementRef } from '@angular/core';
export declare class HighchartsChartComponent {
    theChart: ElementRef;
    constructor();
    render(chartData: any): void;
    createGuid(): string;
    s4(): string;
}
